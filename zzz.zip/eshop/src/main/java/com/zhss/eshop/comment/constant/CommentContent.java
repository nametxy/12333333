package com.zhss.eshop.comment.constant;

/**
 * 评论内容的常量类
 * @author zhonghuashishan
 *
 */
public class CommentContent {

	public static final String DEFAULT = "非常好的商品！";
	
}
